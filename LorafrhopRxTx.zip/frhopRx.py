from machine import Pin, SPI, Timer, UART
from sx127x import SX127x
import time
import struct
import uhashlib
import utime

# Initialize UART (using different pins, for example, TX on Pin 12, RX on Pin 13)
uart = UART(0, baudrate=115200, tx=Pin(12), rx=Pin(13))

# Function to send the 5-byte payload to UART
def send_values_to_uart(values):
    # Send the 5-byte values to UART
    uart.write(values)

# Function to calculate the frequency from the channel index (0 to 20 maps to 433 MHz to 453 MHz)
def calculate_frequency(channel):
    return 433500000 + channel * 3000000  # Each channel step is 1 MHz

# Simple modulo counter
def simple_modulo_counter(counter):
    # Channel is just the counter modulo 21
    return counter % 7

# Improved pseudorandom sequence generator
def pseudorandom_sequence(seed, counter):
    # Concatenate seed and counter as a string and hash it
    data = str(seed) + str(counter)
    
    # Use SHA256 hashing for better randomness and take only the first 3 bytes
    h = uhashlib.sha256(data.encode())
    hashed_value = h.digest()
    
    # Convert the first 3 bytes to an integer and return a value between 0 and 20
    random_value = int.from_bytes(hashed_value[:3], 'big') % 7
    
    return random_value

# Function to generate HMAC-SHA256 and truncate to 6 bytes
def generate_hmac(key, message):
    h = uhashlib.sha256(key)
    h.update(message)
    hmac = h.digest()
    return hmac[:6]

# Function to verify HMAC
def verify_hmac(key, message):
    received_data = message[:-6]  # Exclude the last 6 bytes (HMAC)
    received_hmac = message[-6:]  # Last 6 bytes (HMAC)
    expected_hmac = generate_hmac(key, received_data)
    return received_hmac == expected_hmac

# Define the pins connected to the SX1276
spi = SPI(0, baudrate=10000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=Pin(16))

pins = {
    "ss": 17,    # Chip Select
    "reset": 0,  # Reset
    "dio_0": 1   # DIO0
}

# Reset the SX1276 module
reset = Pin(pins["reset"], Pin.OUT)
reset.value(0)
time.sleep(0.1)
reset.value(1)
time.sleep(0.1)

# Initialize the SX127x parameters
parameters = {
    "frequency": 433500000,  # Initial frequency (this will change in hopping)
    "tx_power_level": 1,
    "signal_bandwidth": 250e3,
    "spreading_factor": 7,
    "coding_rate": 5,
    "preamble_length": 8,
    "sync_word": 0x12,
    "enable_CRC": True,
    "invert_IQ": False
}

# Initialize the SX1276
lora = SX127x(spi, pins, parameters)

# Check if the module responds with a valid version
version = lora.readRegister(0x42)
print("SX version: {}".format(version))

if version != 0x12:
    print("Failed to initialize SX1276, check wiring and connections.")
else:
    print("Initialization successful!")

    # Receiver logic variables
    seed = 12345  # Must match the transmitter's seed
    counter = 1  # Initialize counter for pseudorandom generator

    # Function to extract counter from received payload
    def extract_counter_from_payload(payload):
        # Extract the first 3 bytes of the payload as the counter
        counter_bytes = payload[:3]
        # Unpack the counter as an unsigned integer (3 bytes)
        extracted_counter = struct.unpack('>I', b'\x00' + counter_bytes)[0]  # Add a leading 0 byte for 4-byte unpacking
        return extracted_counter
    

# Global variable to track the last valid counter
last_valid_counter = 0  # Initialize with 0 (or any suitable starting value)

# Function to discard old packets and avoid replay attacks
def is_valid_packet_counter(new_counter):
    global last_valid_counter
    if new_counter > last_valid_counter:
        last_valid_counter = new_counter  # Update to the new valid counter
        return True
    else:
        return False  # Invalid packet (replay attack)

# Updated receive_lora_message function with replay attack prevention
def receive_lora_message():
    total_packets = 0
    total_timeouts = 0
    global counter
    global packet_received
    global last_valid_counter
    out_of_sync = False  # Tracks sync state
    consecutive_timeouts = 0  # Tracks consecutive timeouts

    print("LoRa Receiver")
    
    normal_timeout_duration = 90  # ms timeout in sync mode
    out_of_sync_timeout_duration = normal_timeout_duration * 2  # double the timeout in out_of_sync mode
    timeout_duration = normal_timeout_duration  # initially in sync
    last_packet_time = utime.ticks_ms()  # Track the time of the last received packet
    pairing_key = b'secret12'  # Must match the transmitter's pairing key

    while True:
        utime.sleep_ms(1)
        
        if lora.receivedPacket():  # Packet received
            start_time = utime.ticks_ms()
            try:
                # Read the raw payload without decoding
                payload = lora.readPayload()
                
                # Verify HMAC integrity
                if verify_hmac(pairing_key, payload):
                    print("HMAC verification succeeded")

                    # Extract the counter from the payload
                    counter = extract_counter_from_payload(payload[:3])  # First 3 bytes for the counter
                    print("Counter extracted from payload: ", counter)
                    
                    # Check if the counter is valid (avoid replay attacks)
                    if not is_valid_packet_counter(counter):
                        print("Packet discarded: Replay attack detected")
                        continue  # Skip further processing of this packet
                    
                    # Extract the next 5 bytes for values
                    values = payload[3:8]  # Bytes 4 to 8 are the values
                    print("Values extracted: ", values)
                    
                    # Send the 5 bytes of values to UART for the flight controller
                    send_values_to_uart(values)
                    
                    # Calculate the next frequency using the counter and seed
                    channel = pseudorandom_sequence(seed, counter + 1)
                    next_frequency = calculate_frequency(channel)
                    
                    # Set the new frequency
                    lora.setFrequency(next_frequency)
                    print(f"Frequency changed to: {next_frequency / 1e6} MHz")
                    
                    # Print raw bytes in hex format
                    print("Raw RX Payload: ", payload.hex())
                    
                    # Get and display RSSI (Received Signal Strength Indicator)
                    rssi = lora.packetRssi()
                    print("RSSI: {}".format(rssi))
                    
                    total_packets += 1
                    print("Packets: {}".format(total_packets))
                    print("Timeouts: {}".format(total_timeouts))
                    
                    # Reset sync state and timeouts on successful packet receipt
                    consecutive_timeouts = 0
                    out_of_sync = False
                    timeout_duration = normal_timeout_duration
                    
                    # Update the last packet received time
                    last_packet_time = utime.ticks_ms()
                else:
                    print("HMAC verification failed, packet discarded")

            except Exception as e:
                print("Error:", e)

            end_time = utime.ticks_ms()
            duration = utime.ticks_diff(end_time, start_time)  # Calculate the time difference
            print("Polling took {} ms".format(duration))
        
        else:
            # Check if timeout_duration has passed since the last packet
            current_time = utime.ticks_ms()
            if utime.ticks_diff(current_time, last_packet_time) > timeout_duration:
                # Increment the channel by 2 and change the frequency
                counter = counter + 2
                channel = pseudorandom_sequence(seed, counter)
                next_frequency = calculate_frequency(channel)
                
                # Set the new frequency
                lora.setFrequency(next_frequency)
                print(f"Timeout: Frequency changed to {next_frequency / 1e6} MHz")
                
                # Update the last packet received time to avoid multiple frequency changes
                last_packet_time = current_time
                total_timeouts += 1
                consecutive_timeouts += 1
                
                # Check if out_of_sync mode needs to be entered
                if consecutive_timeouts >= 3:
                    out_of_sync = True
                    timeout_duration = out_of_sync_timeout_duration
                    print("Entered out_of_sync mode: Timeout duration doubled")


# Call the receive function to start receiving messages
receive_lora_message()
