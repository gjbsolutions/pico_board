from machine import Timer, ADC, Pin, SPI
from sx127x import SX127x
import time
import uhashlib
import ubinascii
import struct
import utime

# Initialize ADC pins (A0, A1, A2)
adc0 = ADC(Pin(26))  # Use GPIO 26 for A0
adc1 = ADC(Pin(27))  # Use GPIO 27 for A1
adc2 = ADC(Pin(28))  # Use GPIO 28 for A2

# Initialize DIO pins
dio_pins = [Pin(i, Pin.IN) for i in range(2, 8)]  # Pins 2 to 7 for DIO

# Global variable to use in the second byte
input_var = 42  # Example value

# Function to read ADC values and DIO pins
def read_sensors():
    # Read ADC values and scale to fit into 1 byte (0-255)
    adc_value_0 = min(adc0.read_u16() >> 8, 255)  # Scale 0-65535 to 0-255
    adc_value_1 = min(adc1.read_u16() >> 8, 255)
    adc_value_2 = min(adc2.read_u16() >> 8, 255)

    # Read DIO pins (6 pins = 0-63, which fits into 1 byte)
    dio_value = 0
    for i in range(6):
        dio_value |= (dio_pins[i].value() << i)  # Build a value from the pin states

    # Ensure the DIO value is only 6 bits and occupy one byte
    dio_value &= 0x3F  # Mask to ensure it's within 6 bits

    # Use global variable in the second byte
    second_byte = input_var & 0xFF  # Limit to 1 byte

    # Create a 5-byte packet: 3 bytes for ADC values, 1 byte for DIO, and 1 byte for the global variable
    packet = struct.pack('>BBBBB', adc_value_0, adc_value_1, adc_value_2, dio_value, second_byte)
    return packet

# Function to generate HMAC-SHA256 and truncate to 6 bytes
def generate_hmac(key, message):
    h = uhashlib.sha256(key)
    h.update(message)
    hmac = h.digest()
    return hmac[:6]

# Function to verify HMAC
def verify_hmac(key, message):
    received_data = message[:-6]
    received_hmac = message[-6:]
    expected_hmac = generate_hmac(key, received_data)
    return received_hmac == expected_hmac

# Function to create an 8-byte packet with a 3-byte counter
def create_packet(counter, payload):
    # Ensure the counter is 3 bytes and payload is 5 bytes to fit in the 8-byte packet
    counter_bytes = struct.pack('>I', counter)[-3:]  # Take the last 3 bytes of a 4-byte integer
    payload_bytes = payload[:5] + b'\x00' * (5 - len(payload))  # Ensure the payload is exactly 5 bytes
    return counter_bytes + payload_bytes

# Improved pseudorandom sequence generator
def pseudorandom_sequence(seed, counter):
    # Concatenate seed and counter as a string and hash it
    data = str(seed) + str(counter)
    
    # Use SHA256 hashing for better randomness and take only the first 3 bytes
    h = uhashlib.sha256(data.encode())
    hashed_value = h.digest()
    
    # Convert the first 3 bytes to an integer and return a value between 0 and 6
    random_value = int.from_bytes(hashed_value[:3], 'big') % 7
    
    return random_value

# Simple modulo counter
def simple_modulo_counter(counter):
    # Channel is just the counter modulo 7
    return counter % 7


# Function to calculate the frequency from the channel index (0 to 20 maps to 433 MHz to 453 MHz)
def calculate_frequency(channel):
    return 433500000 + channel * 3000000  # Each channel step is 1 MHz

# Define the pins connected to the SX1276
spi = SPI(0, baudrate=10000000, polarity=0, phase=0,
          sck=Pin(18), mosi=Pin(19), miso=Pin(16))

pins = {
    "ss": 17,    # Chip Select
    "reset": 0,  # Reset
    "dio_0": 1   # DIO0
}

# Reset the SX1276 module
reset = Pin(pins["reset"], Pin.OUT)
reset.value(0)
time.sleep(0.1)
reset.value(1)
time.sleep(0.1)

# Initialize the SX127x parameters
parameters = {
    "frequency": 433500000,  # Initial frequency (this will change in hopping)
    "tx_power_level": 1,
    "signal_bandwidth": 250e3,
    "spreading_factor": 7,
    "coding_rate": 5,
    "preamble_length": 8,
    "sync_word": 0x12,
    "enable_CRC": True,
    "invert_IQ": False
}

# Initialize the SX1276
lora = SX127x(spi, pins, parameters)

# Check if the module responds with a valid version
version = lora.readRegister(0x42)
print("SX version: {}".format(version))

if version != 0x12:  # 0x12 is the expected version for SX1276
    print("Failed to initialize SX1276, check wiring and connections.")
else:
    # Function to send data over LoRa
    def send_lora_message(message):
        lora.println(message)
        print("Message sent: ", ubinascii.hexlify(message))

    # Example counter and payload
    counter = 1
    payload = b'ABCDE'
    pairing_key = b'secret12'  # 8-byte pairing key
    seed = 12345  # You can change the seed

    # Timer callback function for frequency hopping every 0.1 second
    def timer_callback(timer):
        global counter
        
        # Measure start time
        start_time = utime.ticks_ms()
        
        # Create the 8-byte packet with the counter and payload
        payload = read_sensors()
        data = create_packet(counter, payload)

        # Generate HMAC and append it to the packet
        hmac = generate_hmac(pairing_key, data)
        message = data + hmac

        # Generate the next pseudorandom channel index
        channel = pseudorandom_sequence(seed, counter)
        # channel = simple_modulo_counter(counter)

        # Calculate the frequency from the channel index (0 to 20)
        frequency = calculate_frequency(channel)
        lora.setFrequency(frequency)  # Set the frequency to the calculated value
        print(f"CNTR {counter} Payload {payload} Transmitting on channel {channel} with frequency {frequency / 1e6} MHz")

        # Send the LoRa message
        send_lora_message(message)
        
        counter += 1  # Increment the counter
        
        # Measure end time and calculate duration
        end_time = utime.ticks_ms()
        duration = utime.ticks_diff(end_time, start_time)  # Calculate the time difference in ms
        print(f"Timer callback execution time: {duration} ms")

    # Create a timer object
    timer = Timer()

    # Initialize the timer to trigger the callback every 100ms (0.1 second)
    timer.init(freq=12, mode=Timer.PERIODIC, callback=timer_callback)

    # Main loop, can handle other tasks
    while True:
        # LoRa communication is handled by the timer callback
        utime.sleep_ms(1)  # Small delay to allow the main loop to keep running

