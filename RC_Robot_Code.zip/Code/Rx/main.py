from machine import Pin, PWM, UART
from time import sleep
import ssd1306
import framebuf

class DualMotor:
    def __init__(self, pwm_pin1, in1_pin1, in2_pin1, pwm_pin2, in1_pin2, in2_pin2):
        self.speed_pin1 = PWM(Pin(pwm_pin1))
        self.speed_pin2 = PWM(Pin(pwm_pin2))
        self.speed_pin1.freq(1000)
        self.speed_pin2.freq(1000)
        self.IN1_1 = Pin(in1_pin1, Pin.OUT)
        self.IN2_1 = Pin(in2_pin1, Pin.OUT)
        self.IN1_2 = Pin(in1_pin2, Pin.OUT)
        self.IN2_2 = Pin(in2_pin2, Pin.OUT)

    def set_speed(self, speed):
        self.speed_pin1.duty_u16(speed)
        self.speed_pin2.duty_u16(speed)

    def spin_both_forward(self, speed, duration):
        self.set_speed(speed)
        self.IN1_1.low()
        self.IN2_1.high()
        self.IN1_2.low()
        self.IN2_2.high()
        sleep(duration)
        self.stop_both()

    def spin_both_backward(self, speed, duration):
        self.set_speed(speed)
        self.IN1_1.high()
        self.IN2_1.low()
        self.IN1_2.high()
        self.IN2_2.low()
        sleep(duration)
        self.stop_both()

    def turn_left(self, speed, duration):
        self.set_speed(speed)
        self.IN1_1.low()
        self.IN2_1.high()
        self.IN1_2.low()
        self.IN2_2.low()
        sleep(duration)
        self.stop_both()

    def turn_right(self, speed, duration):
        self.set_speed(speed)
        self.IN1_1.low()
        self.IN2_1.low()
        self.IN1_2.low()
        self.IN2_2.high()
        sleep(duration)
        self.stop_both()

    def stop_both(self):
        self.set_speed(0)
        self.IN1_1.low()
        self.IN2_1.low()
        self.IN1_2.low()
        self.IN2_2.low()
        
# OLED Screen Setup
i2c = machine.SoftI2C(scl=machine.Pin(17), sda=machine.Pin(16))
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

uart = UART(1, 9600, tx=Pin(8), rx=Pin(9), timeout=400)

# HC12 Set pin GP18 to output mode
pin = Pin(18, Pin.OUT)

# Set the pin to 0 (low) for AT
pin.value(1)

key2button_pin = machine.Pin(20, machine.Pin.IN, machine.Pin.PULL_UP)
key1button_pin = machine.Pin(21, machine.Pin.IN, machine.Pin.PULL_UP)

motors = DualMotor(pwm_pin1=10, in1_pin1=12, in2_pin1=13, pwm_pin2=11, in1_pin2=14, in2_pin2=15)

oled.fill(0)
oled.text('TT Robot', 0, 0)
oled.show()

while True:
    if not key1button_pin.value():
        #uart.write(' LEFT')  # Send the user input over UART
        motors.turn_left(speed=55000, duration=2)
    if not key2button_pin.value():
        #uart.write(' RIGHT')  # Send the user input over UART
        motors.turn_right(speed=55000, duration=2)
    
    if uart.any():
        data = uart.read().decode().strip()
        print(data)
        oled.fill(0)
        oled.text(data, 0, 0)
        oled.show()
        if data == 'L':
            motors.turn_left(speed=55000, duration=0.3)
        if data == 'R':
            motors.turn_right(speed=55000, duration=0.3)
        if data == 'F':
            motors.spin_both_forward(speed=55000, duration=1.5)
        if data == 'B':
            motors.spin_both_backward(speed=55000, duration=1.5)
    
    sleep(0.1)

