# Import necessary modules
from machine import Pin, UART, ADC 
import bluetooth
from ble_simple_peripheral import BLESimplePeripheral
import ssd1306
import framebuf

# OLED Screen Setup
i2c = machine.SoftI2C(scl=machine.Pin(17), sda=machine.Pin(16))
oled_width = 128
oled_height = 64
oled = ssd1306.SSD1306_I2C(oled_width, oled_height, i2c)

# HC12 Setup
uart = machine.UART(1, 9600, tx=machine.Pin(8), rx=machine.Pin(9), timeout=400)
pin = machine.Pin(18, machine.Pin.OUT)
# Set the pin to 0 (low) for AT
pin.value(1)

# Battery measurement
potentiometer = machine.ADC(28)

# Create a Bluetooth Low Energy (BLE) object
ble = bluetooth.BLE()

# Create an instance of the BLESimplePeripheral class with the BLE object
sp = BLESimplePeripheral(ble)

# Create a Pin object for the onboard LED, configure it as an output
led = Pin("LED", Pin.OUT)

# Initialize the LED state to 0 (off)
led_state = 0

# Define a callback function to handle received data
def on_rx(data):
    print("Data received: ", data)  # Print the received data
    oled.fill(0)
    oled.text(data.decode().strip(), 0, 0)
    oled.show()
    uart.write(data)
    global led_state  # Access the global variable led_state
    if data == b'toggle\r\n':  # Check if the received data is "toggle"
        led.value(not led_state)  # Toggle the LED state (on/off)
        led_state = 1 - led_state  # Update the LED state
        msg="led state changed\n"
        sp.send(msg)
    if data == b'bat\r\n':  # Check if the received data is "bat"     
        sensor_value = 4 * 3.3 * potentiometer.read_u16() / 65536
        rounded_value = round(sensor_value, 2)
        msg="bat voltage " + str(rounded_value) +"\n"
        sp.send(msg)

# Start an infinite loop
while True:
    if sp.is_connected():  # Check if a BLE connection is established
        sp.on_write(on_rx)  # Set the callback function for data reception